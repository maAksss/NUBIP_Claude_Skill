#!/usr/bin/env python3
"""Перевірка .docx на відповідність вимогам НУБіП до оформлення МКР.

Використання: python check_format.py файл.docx

Перевіряє: формат A4, поля, шрифт і кегль основного тексту, міжрядковий
інтервал, абзацний відступ, заголовки структурних частин, крапки в кінці
заголовків, «Таблиця»/«Рис.» підписи, наявність номера сторінки в колонтитулі.
Це евристична перевірка: результат "ПОПЕРЕДЖЕННЯ" потребує погляду людини.
"""
import re
import sys

from docx import Document
from docx.shared import Mm, Pt

TOL_MM = 1.0
STRUCT_HEADINGS = {
    "ЗМІСТ", "ПЕРЕЛІК УМОВНИХ ПОЗНАЧЕНЬ", "ВСТУП", "ВИСНОВКИ",
    "СПИСОК ВИКОРИСТАНИХ ДЖЕРЕЛ", "ДОДАТКИ", "РЕФЕРАТ",
}
FONT = "Times New Roman"

problems = []
warnings = []


def mm(emu):
    return emu / 36000.0


def check_section(doc):
    for i, s in enumerate(doc.sections, 1):
        w, h = mm(s.page_width), mm(s.page_height)
        if not (abs(w - 210) < TOL_MM and abs(h - 297) < TOL_MM):
            if not (abs(w - 297) < TOL_MM and abs(h - 420) < TOL_MM):
                problems.append(f"Секція {i}: розмір сторінки {w:.0f}×{h:.0f} мм, потрібно A4 210×297")
        want = {"left": 30, "right": 10, "top": 20, "bottom": 20}
        got = {
            "left": mm(s.left_margin), "right": mm(s.right_margin),
            "top": mm(s.top_margin), "bottom": mm(s.bottom_margin),
        }
        for k, v in want.items():
            if abs(got[k] - v) > TOL_MM:
                problems.append(f"Секція {i}: поле {k} = {got[k]:.1f} мм, потрібно {v} мм")


def effective_font(par, doc):
    """Повертає (ім'я шрифту, кегль у pt) для першого run або зі стилю."""
    name = size = None
    for r in par.runs:
        if r.text.strip():
            name = name or r.font.name
            size = size or (r.font.size.pt if r.font.size else None)
            break
    st = par.style
    while st is not None and (name is None or size is None):
        if name is None and st.font.name:
            name = st.font.name
        if size is None and st.font.size:
            size = st.font.size.pt
        st = st.base_style
    if name is None and doc.styles["Normal"].font.name:
        name = doc.styles["Normal"].font.name
    if size is None and doc.styles["Normal"].font.size:
        size = doc.styles["Normal"].font.size.pt
    return name, size


def effective_spacing(par, doc):
    ls = par.paragraph_format.line_spacing
    st = par.style
    while ls is None and st is not None:
        ls = st.paragraph_format.line_spacing
        st = st.base_style
    if ls is None:
        ls = doc.styles["Normal"].paragraph_format.line_spacing
    return ls


def effective_indent(par):
    fi = par.paragraph_format.first_line_indent
    st = par.style
    while fi is None and st is not None:
        fi = st.paragraph_format.first_line_indent
        st = st.base_style
    return fi


def is_heading(par):
    return par.style is not None and par.style.name.lower().startswith(("heading", "заголовок"))


def check_body(doc):
    bad_font = bad_size = bad_spacing = bad_indent = 0
    body_count = 0
    first_bad = {}
    for idx, p in enumerate(doc.paragraphs):
        text = p.text.strip()
        if not text or is_heading(p):
            continue
        # довгі абзаци вважаємо основним текстом
        if len(text) < 120:
            continue
        body_count += 1
        name, size = effective_font(p, doc)
        if name and name != FONT:
            bad_font += 1
            first_bad.setdefault("font", (idx, name))
        if size and abs(size - 14) > 0.1:
            bad_size += 1
            first_bad.setdefault("size", (idx, size))
        ls = effective_spacing(p, doc)
        if ls is not None:
            if hasattr(ls, "pt"):  # точний інтервал у pt, а не множник
                bad_spacing += 1
                first_bad.setdefault("spacing", (idx, f"{ls.pt:.0f} pt (точно)"))
            elif not 1.45 <= float(ls) <= 1.55:
                bad_spacing += 1
                first_bad.setdefault("spacing", (idx, ls))
        fi = effective_indent(p)
        if fi is not None and abs(mm(fi) - 12.5) > 1.5:
            bad_indent += 1
            first_bad.setdefault("indent", (idx, mm(fi)))
        elif fi is None and p.alignment is not None:
            bad_indent += 1
            first_bad.setdefault("indent", (idx, None))
    if body_count == 0:
        warnings.append("Не знайдено довгих абзаців основного тексту для перевірки.")
        return
    if bad_font:
        problems.append(f"Шрифт не {FONT} у {bad_font} абзацах (напр. абзац №{first_bad['font'][0]}: {first_bad['font'][1]})")
    if bad_size:
        problems.append(f"Кегль не 14 pt у {bad_size} абзацах (напр. №{first_bad['size'][0]}: {first_bad['size'][1]} pt)")
    if bad_spacing:
        problems.append(f"Міжрядковий інтервал не 1,5 у {bad_spacing} абзацах (напр. №{first_bad['spacing'][0]}: {first_bad['spacing'][1]})")
    if bad_indent:
        warnings.append(f"Абзацний відступ відрізняється від ≈1,25 см у {bad_indent} абзацах (напр. №{first_bad['indent'][0]}: {first_bad['indent'][1]})")


def check_headings(doc):
    for idx, p in enumerate(doc.paragraphs):
        t = p.text.strip()
        if not t:
            continue
        up = t.upper().rstrip(".")
        # структурні частини
        if up in STRUCT_HEADINGS or re.fullmatch(r"\d+\.\s*(ВСТУП|ВИСНОВКИ|ЗМІСТ)", up):
            if t.rstrip(".") != up:
                problems.append(f"Заголовок «{t}» (абзац №{idx}) має бути ВЕЛИКИМИ літерами")
            if re.match(r"^\d", t):
                problems.append(f"Заголовок «{t}» (абзац №{idx}) не повинен мати номера")
            if t.endswith("."):
                problems.append(f"Заголовок «{t}» (абзац №{idx}): крапка в кінці не ставиться")
        m = re.match(r"^РОЗДІЛ\s+(\S+)", t)
        if m:
            num = m.group(1).rstrip(".")
            if not num.isdigit():
                warnings.append(f"«{t[:40]}»: номер розділу «{num}» не арабською цифрою (див. «Неоднозначності»)")
            if m.group(1).endswith("."):
                warnings.append(f"«{t[:40]}»: після номера розділу крапка не ставиться")
            if t != up:
                problems.append(f"Заголовок розділу «{t[:40]}» (абзац №{idx}) має бути ВЕЛИКИМИ літерами")
        sub = re.match(r"^(\d+\.\d+)\.?\s+(.+)$", t)
        if sub and is_heading(p):
            if not t.startswith(sub.group(1) + "."):
                warnings.append(f"Підрозділ «{t[:40]}»: після номера має стояти крапка («{sub.group(1)}.»)")
            title = sub.group(2)
            if title.endswith(".") and len(t) < 120:
                warnings.append(f"Підрозділ «{t[:40]}»: крапка в кінці назви підрозділу не ставиться")
            if title.isupper():
                problems.append(f"Підрозділ «{t[:40]}»: назва має бути малими літерами (крім першої)")


def check_captions(doc):
    tab = re.compile(r"^Таблиця\s+(\d+\.\d+|[А-Я]\.\d+)")
    fig = re.compile(r"^Рис\.\s*(\d+\.\d+|[А-Я]\.\d+)")
    n_tab = n_fig = 0
    for idx, p in enumerate(doc.paragraphs):
        t = p.text.strip()
        if tab.match(t):
            n_tab += 1
        elif t.lower().startswith("таблиця") and re.match(r"^таблиця\s+\d+\s*$", t.lower()):
            warnings.append(f"Абзац №{idx}: «{t}» без розділу в нумерації (потрібно «Таблиця 2.1»)")
        if fig.match(t):
            n_fig += 1
        elif re.match(r"^Рис\.?\s*\d+\s*[.\s]", t):
            warnings.append(f"Абзац №{idx}: «{t[:30]}» — нумерація рисунка без розділу (потрібно «Рис. 3.1.»)")
    print(f"Знайдено підписів: таблиць {n_tab}, рисунків {n_fig}; таблиць у документі {len(doc.tables)}")
    if len(doc.tables) and n_tab < len(doc.tables):
        warnings.append(f"Таблиць {len(doc.tables)}, а підписів «Таблиця N.N» лише {n_tab}")


def check_tables(doc):
    small = 0
    for t in doc.tables:
        for row in t.rows:
            h = row.height
            if h is not None and mm(h) < 8 - 0.5:
                small += 1
    if small:
        warnings.append(f"{small} рядків таблиць мають висоту менше 8 мм")


def check_page_numbers(doc):
    found = False
    for s in doc.sections:
        for hf in (s.header, s.first_page_header, s.footer):
            xml = hf._element.xml if hf is not None else ""
            if "PAGE" in xml:
                found = True
    if not found:
        warnings.append("У колонтитулах не знайдено поля PAGE (номер сторінки угорі праворуч)")
    first = doc.sections[0]
    if not first.different_first_page_header_footer:
        warnings.append("Для першої сторінки (картка МКР) не ввімкнено «Інший колонтитул першої сторінки»: номер на ній не має стояти")


def main():
    if len(sys.argv) != 2:
        print(__doc__)
        sys.exit(2)
    doc = Document(sys.argv[1])
    check_section(doc)
    check_body(doc)
    check_headings(doc)
    check_captions(doc)
    check_tables(doc)
    check_page_numbers(doc)
    print()
    if problems:
        print("ПОМИЛКИ:")
        for p in problems:
            print("  -", p)
    if warnings:
        print("ПОПЕРЕДЖЕННЯ:")
        for w in warnings:
            print("  -", w)
    if not problems and not warnings:
        print("Відхилень не знайдено.")
    sys.exit(1 if problems else 0)


if __name__ == "__main__":
    main()
